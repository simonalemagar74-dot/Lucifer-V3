package com.lucifer.assistant.memory

import android.content.Context
import com.lucifer.assistant.ChatMessage
import com.lucifer.assistant.MessageKind
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Keeps the current conversation on this phone so Lucifer still has the context after the app is
 * closed or restarted. It is only written while "Let Lucifer remember things" is on, and it is
 * deleted by "Start a new conversation" or by switching memory off.
 *
 * Only a conversation that ends cleanly (the AI's final text answer) is saved, so a restored
 * history is always valid for the AI.
 */
class ConversationStore(context: Context) {
    private val dir: File = context.applicationContext.filesDir
    private val file = File(dir, FILE_NAME)

    /** A restored conversation. Message ids are placeholders; the caller assigns real ones. */
    class Saved(val contents: JSONArray, val messages: List<ChatMessage>)

    fun load(): Saved? {
        if (!file.exists()) return null
        return try {
            val saved = decode(file.readText())
            if (saved == null) {
                // Keep a copy of something we could not read instead of silently destroying it.
                file.renameTo(File(dir, "$FILE_NAME.bad"))
            }
            saved
        } catch (e: Exception) {
            null
        }
    }

    fun save(contents: JSONArray, messages: List<ChatMessage>) {
        try {
            val text = encode(contents, messages)
            val tmp = File(dir, "$FILE_NAME.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(file)) {
                file.writeText(text)
                tmp.delete()
            }
        } catch (e: Exception) {
            // Saving context is a convenience; never let it break a conversation.
        }
    }

    fun clear() {
        try {
            file.delete()
        } catch (e: Exception) {
            // Nothing else to do.
        }
    }

    companion object {
        private const val FILE_NAME = "conversation.json"
        private const val VERSION = 1
        private const val MAX_MESSAGES = 80

        fun encode(contents: JSONArray, messages: List<ChatMessage>): String {
            val msgs = JSONArray()
            messages
                .filter { it.kind != MessageKind.ERROR }
                .takeLast(MAX_MESSAGES)
                .forEach { msgs.put(JSONObject().put("k", it.kind.name).put("t", it.text)) }
            return JSONObject()
                .put("v", VERSION)
                .put("contents", contents)
                .put("messages", msgs)
                .toString()
        }

        /** Returns null if the text is not a valid saved conversation. */
        fun decode(raw: String): Saved? = try {
            val root = JSONObject(raw)
            val contents = root.getJSONArray("contents")
            if (root.optInt("v") != VERSION || !isValidHistory(contents)) {
                null
            } else {
                val arr = root.optJSONArray("messages") ?: JSONArray()
                val messages = ArrayList<ChatMessage>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val kind = try {
                        MessageKind.valueOf(o.getString("k"))
                    } catch (e: IllegalArgumentException) {
                        continue
                    }
                    if (kind == MessageKind.ERROR) continue
                    messages.add(ChatMessage(i.toLong(), kind, o.getString("t")))
                }
                Saved(contents, messages)
            }
        } catch (e: Exception) {
            null
        }

        /** Starts with the user's words, ends with the AI's final text, and has no dangling tool call. */
        fun isValidHistory(c: JSONArray): Boolean {
            if (c.length() < 2) return false
            val first = c.optJSONObject(0) ?: return false
            if (first.optString("role") != "user") return false
            val firstParts = first.optJSONArray("parts") ?: return false
            if (firstParts.length() == 0 || !firstParts.getJSONObject(0).has("text")) return false
            val last = c.optJSONObject(c.length() - 1) ?: return false
            if (last.optString("role") != "model") return false
            val lastParts = last.optJSONArray("parts") ?: return false
            for (i in 0 until lastParts.length()) {
                if (lastParts.getJSONObject(i).has("functionCall")) return false
            }
            return true
        }
    }
}
