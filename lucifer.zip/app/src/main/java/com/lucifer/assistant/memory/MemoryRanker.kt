package com.lucifer.assistant.memory

/**
 * Chooses which saved memories to show the AI for a given message. Sending every memory makes
 * answers slower and costlier as the list grows, so only a limited number are sent: the ones that
 * share words with what the user just said, then the most recent ones.
 */
object MemoryRanker {
    const val DEFAULT_LIMIT = 40

    fun select(all: List<MemoryEntry>, query: String, limit: Int = DEFAULT_LIMIT): List<MemoryEntry> {
        if (limit <= 0) return emptyList()
        if (all.size <= limit) return all

        val wanted = words(query)
        val chosen = LinkedHashSet<Int>()

        if (wanted.isNotEmpty()) {
            all.indices
                .map { i -> i to words(all[i].text).count { it in wanted } }
                .filter { it.second > 0 }
                .sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenByDescending { it.first })
                .take(limit / 2)
                .forEach { chosen.add(it.first) }
        }

        // Fill the rest with the newest memories.
        var i = all.size - 1
        while (chosen.size < limit && i >= 0) {
            chosen.add(i)
            i--
        }
        return chosen.sorted().map { all[it] }
    }

    private fun words(text: String): Set<String> =
        text.lowercase()
            .split(SPLIT)
            .filter { it.length >= 2 && it !in STOP }
            .toSet()

    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")

    private val STOP = setOf(
        "the", "and", "for", "you", "your", "are", "was", "with", "that", "this", "have", "what",
        "can", "please", "lucifer", "tell", "me", "my", "is", "it", "to", "of", "in", "on", "at"
    )
}
