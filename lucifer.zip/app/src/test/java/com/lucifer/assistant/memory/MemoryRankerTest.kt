package com.lucifer.assistant.memory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRankerTest {
    private fun entry(i: Int, text: String) = MemoryEntry("id$i", text, i.toLong())

    @Test
    fun smallListIsReturnedUnchanged() {
        val all = listOf(entry(0, "likes tea"), entry(1, "wakes at six"))
        assertEquals(all, MemoryRanker.select(all, "anything", limit = 5))
    }

    @Test
    fun neverReturnsMoreThanTheLimit() {
        val all = (0 until 100).map { entry(it, "fact number $it") }
        assertEquals(10, MemoryRanker.select(all, "number", limit = 10).size)
    }

    @Test
    fun relevantOldMemoryIsKeptEvenWhenNotRecent() {
        val all = (0 until 100).map { entry(it, "filler note $it") }.toMutableList()
        all[3] = entry(3, "My sister Anita lives in Pokhara")
        val picked = MemoryRanker.select(all, "where does Anita live", limit = 10)
        assertTrue(picked.any { it.id == "id3" })
        assertEquals(10, picked.size)
    }

    @Test
    fun newestMemoriesFillTheRest() {
        val all = (0 until 50).map { entry(it, "note $it") }
        val picked = MemoryRanker.select(all, "zzz", limit = 5)
        assertEquals(listOf("id45", "id46", "id47", "id48", "id49"), picked.map { it.id })
    }

    @Test
    fun resultKeepsOriginalOrder() {
        val all = (0 until 30).map { entry(it, "note $it") }.toMutableList()
        all[2] = entry(2, "birthday is in March")
        val picked = MemoryRanker.select(all, "when is my birthday", limit = 6)
        assertEquals(picked.map { it.id }, picked.map { it.id }.sortedBy { it.removePrefix("id").toInt() })
    }

    @Test
    fun zeroLimitGivesNothing() {
        assertTrue(MemoryRanker.select(listOf(entry(0, "a b")), "a", limit = 0).isEmpty())
    }
}
