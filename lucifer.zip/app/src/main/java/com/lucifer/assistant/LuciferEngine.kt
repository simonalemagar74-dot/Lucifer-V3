package com.lucifer.assistant

import android.app.Application
import android.os.SystemClock
import com.lucifer.assistant.ai.Assistant
import com.lucifer.assistant.ai.GeminiClient
import com.lucifer.assistant.data.Prefs
import com.lucifer.assistant.data.SettingsState
import com.lucifer.assistant.memory.ConversationStore
import com.lucifer.assistant.memory.MemoryStore
import com.lucifer.assistant.tools.AndroidTools
import com.lucifer.assistant.tools.MemoryTools
import com.lucifer.assistant.tools.ScreenTools
import com.lucifer.assistant.tools.ToolGroup
import com.lucifer.assistant.tools.ToolManager
import com.lucifer.assistant.voice.SpeechLang
import com.lucifer.assistant.voice.VoiceManager
import com.lucifer.assistant.voice.VoiceProblem
import com.lucifer.assistant.voice.WakePhrase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import kotlin.coroutines.resume

/** What came back from one round of listening. */
private sealed interface ListenResult {
    class Heard(val text: String) : ListenResult
    class Problem(val problem: VoiceProblem) : ListenResult
    object Cancelled : ListenResult
}

/**
 * The single "brain host" of the app. It lives as long as the app process (not the screen), so
 * Lucifer keeps listening and working while other apps are open. The UI, the listening service and
 * the screen-control overlay all just observe or call it.
 *
 * Everything here runs on the main thread.
 */
class LuciferEngine(private val app: Application) {
    private val prefs = Prefs(app)
    val memory = MemoryStore(app)
    private val conversation = ConversationStore(app)

    private val _settings = MutableStateFlow(prefs.read())
    val settings: StateFlow<SettingsState> = _settings.asStateFlow()

    private val toolManager = ToolManager(
        listOf(
            AndroidTools(app),
            MemoryTools(memory) { _settings.value.memoryEnabled },
            ScreenTools()
        )
    ) { _settings.value.disabledTools }

    val toolGroups: List<ToolGroup> get() = toolManager.groups()

    private val assistant = Assistant(GeminiClient(), toolManager, memory)
    private val voice by lazy { VoiceManager(app) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val contents = JSONArray()
    private var nextId = 0L

    /** The current piece of work (typing, one-shot voice, or answering a heard command). */
    private var workJob: Job? = null
    private var loopJob: Job? = null
    private var listenCont: CancellableContinuation<ListenResult>? = null
    private var followUpUntil = 0L

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        restoreOrWelcome()
    }

    // ------------------------------------------------------------------ typing

    /** Returns false if Lucifer is busy and the message was not taken. */
    fun send(text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty() || isBusy()) return false
        workJob = scope.launch { process(clean, viaVoice = false) }
        // In always-listening mode, stop the current listening round so the loop sees the new work.
        abortListening()
        return true
    }

    private fun isBusy(): Boolean = workJob?.isActive == true

    // ------------------------------------------------------------------ one-shot voice

    /** Call only after microphone permission was granted. Listens once, then answers aloud. */
    fun listenOnceAndProcess() {
        if (isBusy() || _ui.value.handsFree) return
        workJob = scope.launch {
            setOrb(OrbState.LISTENING)
            when (val r = listenOnce(_settings.value)) {
                is ListenResult.Heard -> process(r.text, viaVoice = true)
                is ListenResult.Problem -> addMessage(MessageKind.ERROR, r.problem.message)
                ListenResult.Cancelled -> {}
            }
            setOrb(OrbState.IDLE)
        }
    }

    /** The figure was tapped while Lucifer was busy (or listening in always-listening mode). */
    fun onFigureTapped() {
        val now = SystemClock.elapsedRealtime()
        when (_ui.value.orb) {
            OrbState.LISTENING -> {
                if (_ui.value.handsFree) {
                    // "I'm talking to you": the next thing heard needs no wake word.
                    followUpUntil = now + TAP_WINDOW_MS
                } else {
                    workJob?.cancel()
                    abortListening()
                    setOrb(OrbState.IDLE)
                }
            }
            OrbState.SPEAKING -> voice.stopSpeaking()
            OrbState.THINKING -> workJob?.cancel()
            OrbState.IDLE -> if (_ui.value.handsFree) followUpUntil = now + TAP_WINDOW_MS
        }
    }

    fun onMicDenied() {
        addMessage(
            MessageKind.ERROR,
            "Microphone permission was denied, so I can't listen. You can still type to me, or allow the microphone in your phone's app settings."
        )
    }

    fun reportError(message: String) = addMessage(MessageKind.ERROR, message)

    // ------------------------------------------------------------------ always-listening mode

    /** Starts or stops always-listening mode. Called by [HandsFreeService]. */
    fun setHandsFree(on: Boolean) {
        if (on) {
            if (_ui.value.handsFree) return
            _ui.update { it.copy(handsFree = true) }
            followUpUntil = 0L
            startLoop()
        } else {
            loopJob?.cancel()
            loopJob = null
            abortListening()
            _ui.update { it.copy(handsFree = false, partial = "") }
            if (!isBusy()) setOrb(OrbState.IDLE)
        }
    }

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = scope.launch {
            var failures = 0
            var lastActivity = SystemClock.elapsedRealtime()
            while (isActive && _ui.value.handsFree) {
                if (SystemClock.elapsedRealtime() - lastActivity > IDLE_TIMEOUT_MS) {
                    addMessage(
                        MessageKind.ERROR,
                        "Always-listening turned itself off after 30 minutes without a command, to save battery."
                    )
                    stopFromInside()
                    break
                }
                if (isBusy()) {
                    delay(250)
                    continue
                }
                val s = _settings.value
                setOrb(OrbState.LISTENING)
                when (val r = listenOnce(s)) {
                    is ListenResult.Heard -> {
                        failures = 0
                        val now = SystemClock.elapsedRealtime()
                        val command: String? =
                            if (!s.requireWakePhrase || now < followUpUntil) r.text.trim()
                            else WakePhrase.extract(r.text)
                        if (command != null) {
                            lastActivity = now
                            if (command.isBlank()) {
                                setOrb(OrbState.SPEAKING)
                                speakAndWait("Yes?", s)
                                setOrb(OrbState.IDLE)
                            } else {
                                val work = launch { process(command, viaVoice = true) }
                                workJob = work
                                work.join()
                            }
                            followUpUntil = SystemClock.elapsedRealtime() + FOLLOW_UP_MS
                        }
                    }
                    is ListenResult.Problem -> {
                        val p = r.problem
                        if (p.fatal) {
                            addMessage(MessageKind.ERROR, p.message)
                            stopFromInside()
                            break
                        } else if (p.quiet) {
                            // The speech service worked; it just heard nothing useful.
                            failures = 0
                            delay(150)
                        } else {
                            failures++
                            // Speech-service hiccups are retried quietly; only speak up if they keep happening.
                            if (failures == SHOW_ERROR_AFTER) addMessage(MessageKind.ERROR, p.message)
                            if (failures >= MAX_FAILURES) {
                                addMessage(MessageKind.ERROR, "Always-listening stopped after repeated speech errors. Switch it off and on to try again.")
                                stopFromInside()
                                break
                            }
                            delay(minOf(6000L, 700L * failures))
                        }
                    }
                    ListenResult.Cancelled -> delay(100)
                }
            }
        }
    }

    private fun stopFromInside() {
        abortListening()
        _ui.update { it.copy(handsFree = false, partial = "") }
        setOrb(OrbState.IDLE)
    }

    // ------------------------------------------------------------------ core pipeline

    private suspend fun process(text: String, viaVoice: Boolean) {
        val s = _settings.value
        addMessage(MessageKind.USER, text)
        if (s.apiKey.isBlank()) {
            addMessage(MessageKind.ERROR, "I need your Gemini API key first. Open Settings and paste it in.")
            setOrb(OrbState.IDLE)
            return
        }
        setOrb(OrbState.THINKING)
        try {
            val answer = assistant.reply(s, contents, text) { note ->
                addMessage(MessageKind.TOOL, note)
            }
            addMessage(MessageKind.ASSISTANT, answer)
            persistConversation()
            if (viaVoice || s.speakTyped) {
                setOrb(OrbState.SPEAKING)
                speakAndWait(answer, s)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            addMessage(MessageKind.ERROR, e.message ?: "Something went wrong.")
        } finally {
            setOrb(OrbState.IDLE)
        }
    }

    private suspend fun listenOnce(s: SettingsState): ListenResult {
        try {
            // If the phone's speech service goes silent without answering, give up and try again.
            return withTimeoutOrNull(LISTEN_TIMEOUT_MS) {
              suspendCancellableCoroutine<ListenResult> { cont ->
                listenCont = cont
                cont.invokeOnCancellation {
                    if (listenCont === cont) listenCont = null
                    voice.stopListening()
                }
                fun finish(result: ListenResult) {
                    if (listenCont === cont) listenCont = null
                    if (cont.isActive) cont.resume(result)
                }
                voice.startListening(
                    language = SpeechLang.recognizerTag(s.speechLang),
                    onPartial = { t -> _ui.update { it.copy(partial = t) } },
                    onFinal = { t -> finish(ListenResult.Heard(t)) },
                    onProblem = { p -> finish(ListenResult.Problem(p)) }
                )
              }
            } ?: ListenResult.Cancelled
        } finally {
            _ui.update { it.copy(partial = "") }
        }
    }

    /** Stops the current listening round (if any); the waiting coroutine gets "Cancelled". */
    private fun abortListening() {
        val c = listenCont
        listenCont = null
        voice.stopListening()
        if (c != null && c.isActive) c.resume(ListenResult.Cancelled)
    }

    private suspend fun speakAndWait(text: String, s: SettingsState) {
        // If the speech engine never reports back, stop waiting so Lucifer does not freeze.
        withTimeoutOrNull(30_000L + text.length * 90L) {
            suspendCancellableCoroutine<Unit> { cont ->
                cont.invokeOnCancellation { voice.stopSpeaking() }
                voice.speak(text, SpeechLang.ttsTag(text, s.speechLang)) {
                    if (cont.isActive) cont.resume(Unit)
                }
            }
        }
    }

    // ------------------------------------------------------------------ settings, memory, chat

    fun updateSettings(transform: (SettingsState) -> SettingsState) {
        prefs.write(transform(_settings.value))
        _settings.value = prefs.read()
        if (!_settings.value.memoryEnabled) conversation.clear()
    }

    fun deleteMemory(id: String) = memory.remove(id)

    fun clearMemory() = memory.clear()

    fun newChat() {
        workJob?.cancel()
        abortListening()
        voice.stopSpeaking()
        while (contents.length() > 0) contents.remove(contents.length() - 1)
        conversation.clear()
        _ui.value = UiState(
            messages = listOf(ChatMessage(nextId++, MessageKind.ASSISTANT, welcomeText())),
            handsFree = _ui.value.handsFree
        )
    }

    private fun welcomeText(): String =
        if (_settings.value.apiKey.isBlank()) {
            "Hi, I'm Lucifer. To wake me up, open Settings and paste your free Gemini API key."
        } else {
            "Hi, I'm Lucifer. Switch on Always listening and say \"Lucifer\" followed by what you need, or tap my face to talk, or type below."
        }

    private fun addMessage(kind: MessageKind, text: String) {
        _ui.update { st ->
            val last = st.messages.lastOrNull()
            if (kind == MessageKind.ERROR && last != null && last.kind == MessageKind.ERROR && last.text == text) {
                st // the same error twice in a row is shown once
            } else {
                st.copy(messages = (st.messages + ChatMessage(nextId++, kind, text)).takeLast(MAX_UI_MESSAGES))
            }
        }
    }

    /** Saves the finished conversation so the context survives closing the app (only if memory is on). */
    private fun persistConversation() {
        if (_settings.value.memoryEnabled) conversation.save(contents, _ui.value.messages)
        else conversation.clear()
    }

    private fun restoreOrWelcome() {
        val saved = if (_settings.value.memoryEnabled) conversation.load() else null
        if (saved != null) {
            for (i in 0 until saved.contents.length()) contents.put(saved.contents.get(i))
            val restored = saved.messages.map { ChatMessage(nextId++, it.kind, it.text) }
            if (restored.isNotEmpty()) {
                _ui.update { it.copy(messages = restored) }
                return
            }
        }
        addMessage(MessageKind.ASSISTANT, welcomeText())
    }

    private fun setOrb(state: OrbState) {
        _ui.update { it.copy(orb = state) }
    }

    companion object {
        private const val IDLE_TIMEOUT_MS = 30 * 60 * 1000L
        private const val FOLLOW_UP_MS = 12_000L
        private const val TAP_WINDOW_MS = 15_000L
        private const val MAX_FAILURES = 10
        private const val SHOW_ERROR_AFTER = 3
        private const val LISTEN_TIMEOUT_MS = 25_000L
        private const val MAX_UI_MESSAGES = 200
    }
}
