# Changelog

## 0.2.1 - Voice fix, saved context, faster replies (untested first build)
- Fixed "Speech recognition failed (code 11)" in Always listening: one speech recognizer is now reused
  instead of being destroyed and rebuilt every round; if the phone's speech service still disconnects
  it is rebuilt, and Google's speech service is preferred when installed
- Speech hiccups are retried quietly; an error is only shown if they keep happening (3 in a row),
  and the same error is never shown twice in a row
- Your conversation is saved on the phone (only while memory is on) so context survives closing the
  app; "Start a new conversation" or turning memory off deletes it
- Only the most relevant memories (up to 40) are sent with each question, so answers stay quick as
  memory grows
- Asks Gemini for "low" thinking effort so answers start sooner; if Google rejects that setting the app
  retries without it automatically
- If the chosen Gemini model is retired (404), tries Google's "gemini-flash-latest" shortcut once
- One more retry when Gemini is busy (429/500/503)
- Assistant is told to admit uncertainty, ask one short question when a request is unclear, and save
  decisions when asked
- New unit tests: memory ranking, saved conversation, thinking-setting error detection

## 0.2.0 - Always listening, screen control, new face (untested first build)
- Always-listening mode as a visible foreground service, with a wake phrase ("Lucifer") by default
  and a 30-minute idle shut-off
- Screen control through an Accessibility service you switch on yourself: read screen, tap, type,
  scroll, back/home/recents, wait; password fields are never typed into
- Confirmation rule for risky taps (send, buy, pay, delete, post, call...) tied to your own words
- Small status dot over other apps while Lucifer is listening, thinking or speaking
- Tool manager with per-group on/off switches and visible permission and risk info
- Speech language setting (Auto, English, Hindi, Nepali); Devanagari replies use a Hindi voice
- New particle-style face with Core, Female and Male looks
- Brain now lives in the app process (LuciferEngine) so it keeps working when other apps are open
- YouTube search opens inside the YouTube app when installed
- Fixed signing key so future updates install over this one
- Listening and speaking now have time limits, so a silent speech service cannot freeze Lucifer
- Safer failure path if Android refuses to start background listening

## 0.1.0 - Version 1 (untested first build)
- Gemini chat with function calling
- Voice input and output
- Phone actions: open app, URL, web search, YouTube search, dialer, alarm, timer
- User-controlled memory
- Unit tests for Gemini JSON parsing and memory serialization
