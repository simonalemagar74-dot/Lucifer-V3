package com.lucifer.assistant.memory

import com.lucifer.assistant.ChatMessage
import com.lucifer.assistant.MessageKind
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationStoreTest {
    private fun textItem(role: String, text: String) =
        JSONObject().put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun goodHistory() = JSONArray()
        .put(textItem("user", "hello"))
        .put(textItem("model", "hi there"))

    @Test
    fun roundTripKeepsContextAndMessages() {
        val msgs = listOf(
            ChatMessage(0, MessageKind.USER, "hello"),
            ChatMessage(1, MessageKind.ASSISTANT, "hi there")
        )
        val saved = ConversationStore.decode(ConversationStore.encode(goodHistory(), msgs))
        assertNotNull(saved)
        assertEquals(2, saved!!.contents.length())
        assertEquals(listOf("hello", "hi there"), saved.messages.map { it.text })
        assertEquals(listOf(MessageKind.USER, MessageKind.ASSISTANT), saved.messages.map { it.kind })
    }

    @Test
    fun errorMessagesAreNotSaved() {
        val msgs = listOf(
            ChatMessage(0, MessageKind.USER, "hello"),
            ChatMessage(1, MessageKind.ERROR, "Speech recognition failed"),
            ChatMessage(2, MessageKind.ASSISTANT, "hi there")
        )
        val saved = ConversationStore.decode(ConversationStore.encode(goodHistory(), msgs))!!
        assertTrue(saved.messages.none { it.kind == MessageKind.ERROR })
        assertEquals(2, saved.messages.size)
    }

    @Test
    fun historyEndingInAToolCallIsRejected() {
        val dangling = JSONArray()
            .put(textItem("user", "open youtube"))
            .put(
                JSONObject().put("role", "model").put(
                    "parts",
                    JSONArray().put(
                        JSONObject().put(
                            "functionCall",
                            JSONObject().put("name", "open_app").put("args", JSONObject())
                        )
                    )
                )
            )
        assertFalse(ConversationStore.isValidHistory(dangling))
        assertNull(ConversationStore.decode(ConversationStore.encode(dangling, emptyList())))
    }

    @Test
    fun historyThatDoesNotStartWithUserTextIsRejected() {
        val startsWithModel = JSONArray()
            .put(textItem("model", "hi"))
            .put(textItem("model", "again"))
        assertFalse(ConversationStore.isValidHistory(startsWithModel))
    }

    @Test
    fun garbageIsRejected() {
        assertNull(ConversationStore.decode("not json at all"))
        assertNull(ConversationStore.decode("""{"v":1}"""))
        assertNull(ConversationStore.decode("""{"v":99,"contents":[],"messages":[]}"""))
    }
}
