package com.lucifer.assistant.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThinkingErrorTest {
    @Test
    fun detectsRejectedThinkingSetting() {
        assertTrue(
            GeminiParser.isThinkingSettingError(
                """{"error":{"code":400,"message":"Unknown name \"thinkingLevel\" at 'generation_config.thinking_config'"}}"""
            )
        )
        assertTrue(
            GeminiParser.isThinkingSettingError(
                """{"error":{"message":"Thinking level is not supported for this model."}}"""
            )
        )
    }

    @Test
    fun otherBadRequestsAreNotMistakenForIt() {
        assertFalse(GeminiParser.isThinkingSettingError("""{"error":{"message":"API key not valid."}}"""))
        assertFalse(GeminiParser.isThinkingSettingError("""{"error":{"message":"Function call is missing a thought_signature"}}"""))
        assertFalse(GeminiParser.isThinkingSettingError("not json"))
    }
}
