package com.lucifer.assistant.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Something went wrong while listening.
 * [quiet] = just "nothing heard", not worth showing. [fatal] = retrying will not help.
 */
data class VoiceProblem(val message: String, val quiet: Boolean, val fatal: Boolean = false)

/**
 * Speech input (Android SpeechRecognizer) and speech output (Android TextToSpeech).
 * Must be created and used on the main thread. The microphone is only opened by [startListening],
 * which the app calls after the user granted the permission and chose to listen.
 */
class VoiceManager(context: Context) {
    private val appContext = context.applicationContext

    private val main = Handler(Looper.getMainLooper())

    /**
     * One recognizer is reused for every listening round. Creating and destroying it every round
     * (what version 0.2.0 did) makes some phones' speech service drop the connection, which Android
     * reports as error code 11 ("server disconnected").
     */
    private var recognizer: SpeechRecognizer? = null
    private var round: Round? = null
    private var preferGoogle = true
    private var disconnects = 0

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var utteranceCounter = 0
    private var currentUtterance: String? = null
    private var currentDone: (() -> Unit)? = null

    /** The callbacks of the listening round that is in progress. */
    private class Round(
        val onPartial: (String) -> Unit,
        val onFinal: (String) -> Unit,
        val onProblem: (VoiceProblem) -> Unit
    )

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = firstResult(partialResults)
            if (t.isNotBlank()) round?.onPartial?.invoke(t)
        }

        override fun onResults(results: Bundle?) {
            val r = round ?: return
            round = null
            disconnects = 0
            val t = firstResult(results)
            if (t.isBlank()) {
                r.onProblem(VoiceProblem("I didn't catch that. Try again.", quiet = true))
            } else {
                r.onFinal(t)
            }
        }

        override fun onError(error: Int) {
            val r = round ?: return
            round = null
            when (error) {
                ERROR_SERVER_DISCONNECTED,
                SpeechRecognizer.ERROR_CLIENT -> {
                    // Rebuild the connection; every second failure in a row, try the other speech service.
                    // (A deliberate cancel never gets here: stopListening() clears the round first.)
                    disconnects++
                    resetRecognizer(switchService = disconnects % 2 == 0)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                ERROR_TOO_MANY_REQUESTS,
                SpeechRecognizer.ERROR_SERVER -> resetRecognizer(switchService = false)
                else -> disconnects = 0
            }
            r.onProblem(describe(error))
        }
    }

    init {
        tts = TextToSpeech(appContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
            }
        }
    }

    /** Listens for one phrase. [language] is a tag like "hi-IN", or null for the phone's default. */
    fun startListening(
        language: String?,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onProblem: (VoiceProblem) -> Unit
    ) {
        if (round != null) stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onProblem(
                VoiceProblem(
                    "Speech recognition isn't available on this phone. Make sure the Google app is installed and enabled.",
                    quiet = false,
                    fatal = true
                )
            )
            return
        }
        val r = try {
            recognizer ?: createRecognizer().also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
        } catch (e: Exception) {
            onProblem(VoiceProblem("Couldn't start the speech service. Try again.", quiet = false))
            return
        }
        round = Round(onPartial, onFinal, onProblem)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        if (!language.isNullOrBlank()) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            round = null
            resetRecognizer(switchService = true)
            onProblem(VoiceProblem("Couldn't start listening. Try again.", quiet = false))
        }
    }

    /** Ends the current listening round (if any). The recognizer itself is kept for the next round. */
    fun stopListening() {
        round = null
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            resetRecognizer(switchService = false)
        }
    }

    /** Prefers Google's speech service when it is installed: many phone-maker services disconnect. */
    private fun createRecognizer(): SpeechRecognizer {
        val google = if (preferGoogle) googleService() else null
        if (google != null) {
            try {
                return SpeechRecognizer.createSpeechRecognizer(appContext, google)
            } catch (e: Exception) {
                preferGoogle = false
            }
        }
        return SpeechRecognizer.createSpeechRecognizer(appContext)
    }

    private fun googleService(): ComponentName? {
        return try {
            val found = appContext.packageManager
                .queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
                .firstOrNull { it.serviceInfo != null && it.serviceInfo.packageName == GOOGLE_APP }
            found?.serviceInfo?.let { ComponentName(it.packageName, it.name) }
        } catch (e: Exception) {
            null
        }
    }

    /** Throws the recognizer away (after the current callback has returned) so the next round builds a fresh one. */
    private fun resetRecognizer(switchService: Boolean) {
        if (switchService) preferGoogle = !preferGoogle
        val old = recognizer
        recognizer = null
        if (old != null) {
            main.post {
                try {
                    old.destroy()
                } catch (e: Exception) {
                    // Already released.
                }
            }
        }
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()

    /**
     * Speaks [text] in [languageTag] (null = phone default), then calls [onFinished] on the main
     * thread - also if speech fails or is stopped with [stopSpeaking].
     */
    fun speak(text: String, languageTag: String?, onFinished: () -> Unit) {
        val engine = tts
        if (engine == null || !ttsReady) {
            onFinished()
            return
        }
        val clean = text.replace(Regex("[*_#`>]"), "").trim().take(MAX_SPEECH_CHARS)
        if (clean.isEmpty()) {
            onFinished()
            return
        }
        if (currentDone != null) finishCurrent()
        if (!languageTag.isNullOrBlank()) {
            val r = engine.setLanguage(Locale.forLanguageTag(languageTag))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.getDefault())
            }
        } else {
            engine.setLanguage(Locale.getDefault())
        }
        val id = "lucifer-${utteranceCounter++}"
        currentUtterance = id
        currentDone = onFinished
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                complete(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                complete(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                complete(utteranceId)
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                complete(utteranceId)
            }
        })
        val result = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) {
            finishCurrent()
        }
    }

    /** Hops to the main thread, then finishes the utterance if it is still the current one. */
    private fun complete(utteranceId: String?) {
        main.post {
            if (utteranceId != null && utteranceId == currentUtterance) finishCurrent()
        }
    }

    private fun finishCurrent() {
        val done = currentDone
        currentDone = null
        currentUtterance = null
        done?.invoke()
    }

    fun stopSpeaking() {
        tts?.stop()
        finishCurrent()
    }

    fun shutdown() {
        round = null
        val r = recognizer
        recognizer = null
        try {
            r?.destroy()
        } catch (e: Exception) {
            // Already released.
        }
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun describe(code: Int): VoiceProblem = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            VoiceProblem("I didn't hear anything. Try again.", quiet = true)
        SpeechRecognizer.ERROR_CLIENT ->
            VoiceProblem("The speech service stopped unexpectedly. Try again.", quiet = false)
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            VoiceProblem(
                "Microphone permission is missing. Allow it in your phone's app settings.",
                quiet = false,
                fatal = true
            )
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            VoiceProblem("Speech recognition needs internet and couldn't connect.", quiet = false)
        SpeechRecognizer.ERROR_AUDIO ->
            VoiceProblem("There was a problem with the microphone.", quiet = false)
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
        ERROR_TOO_MANY_REQUESTS ->
            VoiceProblem("The speech service is busy. Trying again.", quiet = false)
        SpeechRecognizer.ERROR_SERVER ->
            VoiceProblem("Google's speech service had a problem. Trying again.", quiet = false)
        ERROR_SERVER_DISCONNECTED ->
            VoiceProblem(
                "Your phone's speech service keeps disconnecting. Update the Google app, and in phone Settings " +
                    "search for \"voice input\" or \"speech services\" and choose Google.",
                quiet = false
            )
        ERROR_LANGUAGE_NOT_SUPPORTED,
        ERROR_LANGUAGE_UNAVAILABLE ->
            VoiceProblem(
                "That speech language isn't available on this phone. Set Speech language to Auto in Settings, " +
                    "or download the language in Google's speech settings.",
                quiet = false,
                fatal = true
            )
        else -> VoiceProblem("Speech recognition failed (code $code). Try again.", quiet = false)
    }

    companion object {
        private const val MAX_SPEECH_CHARS = 3500
        private const val GOOGLE_APP = "com.google.android.googlequicksearchbox"

        // Values of SpeechRecognizer constants that only exist on newer Android versions.
        private const val ERROR_TOO_MANY_REQUESTS = 10
        private const val ERROR_SERVER_DISCONNECTED = 11
        private const val ERROR_LANGUAGE_NOT_SUPPORTED = 12
        private const val ERROR_LANGUAGE_UNAVAILABLE = 13
    }
}
